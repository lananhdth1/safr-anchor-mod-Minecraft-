package com.safeanchor;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.function.Predicate;

public class SafeAnchorClient implements ClientModInitializer {
    private static KeyBinding toggleKey;

    private static BlockPos anchorPos;
    private static Direction anchorFace;
    private static int phase = 0;     // 0 = nap glowstone, 1 = dat block chan, 2 = no
    private static int cooldown = 0;

    @Override
    public void onInitializeClient() {
        Config.load();

        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.safeanchor.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, "category.safeanchor"));

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("safeanchor")
                .then(ClientCommandManager.literal("toggle").executes(ctx -> {
                    toggle(MinecraftClient.getInstance());
                    return 1;
                }))
                .then(ClientCommandManager.literal("delay")
                    .then(ClientCommandManager.argument("ticks", IntegerArgumentType.integer(0, 20))
                        .executes(ctx -> {
                            Config.INSTANCE.delay = IntegerArgumentType.getInteger(ctx, "ticks");
                            Config.save();
                            ctx.getSource().sendFeedback(Text.literal("§aSafe Anchor delay = " + Config.INSTANCE.delay + " tick"));
                            return 1;
                        })))
                .executes(ctx -> {
                    ctx.getSource().sendFeedback(Text.literal("§e/safeanchor toggle | /safeanchor delay <0-20>"));
                    return 1;
                })));
    }

    private static void toggle(MinecraftClient mc) {
        Config.INSTANCE.enabled = !Config.INSTANCE.enabled;
        Config.save();
        reset();
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal("Safe Anchor: " + (Config.INSTANCE.enabled ? "§aON" : "§cOFF")), true);
        }
    }

    private static void reset() {
        anchorPos = null;
        anchorFace = null;
        phase = 0;
        cooldown = 0;
    }

    private void tick(MinecraftClient mc) {
        while (toggleKey.wasPressed()) toggle(mc);

        if (!Config.INSTANCE.enabled || mc.player == null || mc.world == null
                || mc.interactionManager == null || mc.currentScreen != null) {
            reset();
            return;
        }

        // Nha chuot phai -> dung
        if (!mc.options.useKey.isPressed()) {
            reset();
            return;
        }

        // Khoa vao anchor dang nhin luc bat dau giu chuot phai
        if (anchorPos == null) {
            if (mc.crosshairTarget instanceof BlockHitResult hit
                    && hit.getType() == HitResult.Type.BLOCK
                    && mc.world.getBlockState(hit.getBlockPos()).isOf(Blocks.RESPAWN_ANCHOR)) {
                anchorPos = hit.getBlockPos();
                anchorFace = hit.getSide();
                phase = 0;
                cooldown = 0;
            } else {
                return;
            }
        }

        BlockState state = mc.world.getBlockState(anchorPos);
        if (!state.isOf(Blocks.RESPAWN_ANCHOR)) { // da no / bi pha
            anchorPos = null;
            return;
        }

        if (cooldown > 0) { cooldown--; return; }

        var inv = mc.player.getInventory();
        int prevSlot = inv.selectedSlot;
        BlockHitResult anchorHit = new BlockHitResult(Vec3d.ofCenter(anchorPos), anchorFace, anchorPos, false);

        // Buoc 0: nap glowstone
        if (phase == 0) {
            if (state.get(RespawnAnchorBlock.CHARGES) > 0) {
                phase = 1;
            } else {
                int slot = findSlot(mc, s -> s.isOf(Items.GLOWSTONE));
                if (slot == -1) { msg(mc, "§cKhong co glowstone!"); return; }
                use(mc, slot, anchorHit, prevSlot);
                phase = 1;
                cooldown = Config.INSTANCE.delay;
                return;
            }
        }

        // Buoc 1: dat block chan truoc mat
        if (phase == 1) {
            BlockHitResult place = findPlaceHit(mc);
            int slot = findSlot(mc, s -> s.getItem() instanceof BlockItem
                    && !s.isOf(Items.GLOWSTONE) && !s.isOf(Items.RESPAWN_ANCHOR));
            // uu tien obsidian
            int obi = findSlot(mc, s -> s.isOf(Items.OBSIDIAN));
            if (obi != -1) slot = obi;
            phase = 2;
            if (place != null && slot != -1) {
                use(mc, slot, place, prevSlot);
                cooldown = Config.INSTANCE.delay;
                return;
            }
        }

        // Buoc 2: no anchor (cam item khong phai glowstone)
        if (phase == 2) {
            int slot = !inv.getStack(prevSlot).isOf(Items.GLOWSTONE)
                    ? prevSlot : findSlot(mc, s -> !s.isOf(Items.GLOWSTONE));
            if (slot == -1) slot = prevSlot;
            use(mc, slot, anchorHit, prevSlot);
            phase = 0;
            cooldown = Config.INSTANCE.delay;
        }
    }

    private static void use(MinecraftClient mc, int slot, BlockHitResult hit, int prevSlot) {
        var inv = mc.player.getInventory();
        inv.selectedSlot = slot;
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
        mc.player.swingHand(Hand.MAIN_HAND);
        inv.selectedSlot = prevSlot;
    }

    /** Tim vi tri dat block nam giua nguoi choi va anchor (o phia mat anchor dang nhin). */
    private static BlockHitResult findPlaceHit(MinecraftClient mc) {
        BlockPos target = anchorPos.offset(anchorFace);
        if (!mc.world.getBlockState(target).isReplaceable()) return null;
        for (Direction d : Direction.values()) {
            BlockPos support = target.offset(d);
            if (support.equals(anchorPos)) continue;
            if (!mc.world.getBlockState(support).isSolidBlock(mc.world, support)) continue;
            Direction face = d.getOpposite();
            Vec3d pos = Vec3d.ofCenter(support).add(Vec3d.of(face.getVector()).multiply(0.5));
            return new BlockHitResult(pos, face, support, false);
        }
        return null;
    }

    private static int findSlot(MinecraftClient mc, Predicate<ItemStack> p) {
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (!s.isEmpty() && p.test(s)) return i;
        }
        return -1;
    }

    private static void msg(MinecraftClient mc, String text) {
        mc.player.sendMessage(Text.literal(text), true);
    }
}
